$(function(){
    let lastScrollTop = 0;
    const delta = 5;
    const $fixBox = $(".bottomNav");
    const fixBoxHeight = $fixBox.outerHeight();
    let didScroll = false;

    $(window).on("scroll",function(){
        didScroll = true
    });

    setInterval(function(){
        if (didScroll){
            hasScrolled();
            didScroll = false;
        }
    }, 250);

    function hasScrolled(){
        const nowScrollTop = $(this).scrollTop();
        if (Math.abs(lastScrollTop - nowScrollTop) <= delta){
            return;
        }
        if (nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight){
            $fixBox.removeClass("show");
        }else{
            if (nowScrollTop + $(window).height() < $(document).height()){
                $fixBox.addClass("show");
            }
        }
        lastScrollTop = nowScrollTop;
    }
});