function Contact () {
    return(
      <main style={{padding:'0px'}}>
        <h2>튀김빵</h2>
        <div style={{display:'flex', gap:'20px'}}>
            <img
               src="img/IMG31.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG32.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG33.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG34.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

          
            
          </div>
      </main>
    );
}
window.Contact = Contact;