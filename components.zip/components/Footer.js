function Footer () {
    return(
      <footer style={{padding:'0px'}}>
        <h2>페스츄리</h2>
        <div style={{display:'flex', gap:'20px'}}>
            <img
               src="img/IMG41.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG42.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG43.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG44.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG45.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            
          </div>
      </footer>
      
    );
}
window.Footer = Footer;