function Header () {
    return(
      <header style={{padding: '20px', backgroundColor: '#dbab72', color: 'black'}}>
        <h1>
            <a href="index.html" style={{color:'white', textDecoration: 'none'}}>
                성심당
            </a>
        </h1>
      </header>  
    );
}
window.Header = Header;