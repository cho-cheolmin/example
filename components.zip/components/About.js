function About () {
    return(
      <main style={{padding:'0px'}}>
        <h2>일반빵</h2>
        

        <div style={{display:'flex', gap:'20px'}}>
            <img
               src="img/IMG11.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG12.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG13.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG14.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG15.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            
          </div>
      </main>
    );
}
window.About = About;