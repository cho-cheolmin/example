function Home () {
    return(
      <main style={{padding:'0px'}}>
        <h2>성심당빵</h2>
        

        <div style={{display:'flex', gap:'20px'}}>
            <img
               src="img/IMG01.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG02.jpg"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG03.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG04.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            

            <img
               src="img/IMG05.png"
               alt="배너"
               style={{width: '20%', height: 'auto', borderRadius: '8px'}}
            />
            
          </div>
        
      </main>
    );
}
window.Home = Home;