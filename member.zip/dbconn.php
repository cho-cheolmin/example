
<?php
$connect = mysqli_connect("localhost", "wings930", "cjfals17!", "wings930") or
die("SQL server에 연결할 수 없습니다.");

?>
