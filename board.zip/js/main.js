$(function() {
$(document).ready(function() {
// 변수 선언
let cartCount = 2;


// jQuery 객체들
const $hamburgerBtn = $('#hamburgerBtn');
const $sideMenu = $('#sideMenu');
const $sideMenuOverlay = $('#sideMenuOverlay');
const $cartBtn = $('#cartBtn');
const $cartBadge = $('#cartBadge');

// 햄버거 메뉴 토글
function toggleSideMenu() {
    const isOpen = $sideMenu.hasClass('open');
    
    if (isOpen) {
        closeSideMenu();
    } else {
        openSideMenu();
    }
}

function openSideMenu() {
    $hamburgerBtn.addClass('active');
    $sideMenu.addClass('open');
    $sideMenuOverlay.addClass('open');
    $('body').css('overflow', 'hidden'); // 스크롤 방지
}

function closeSideMenu() {
    $hamburgerBtn.removeClass('active');
    $sideMenu.removeClass('open');
    $sideMenuOverlay.removeClass('open');
    $('body').css('overflow', ''); // 스크롤 복원
    
    // 모든 서브메뉴 닫기
    $('.menu-title').removeClass('active');
    $('.submenu').removeClass('open');
}

// 서브메뉴 토글 함수
function toggleSubmenu($menuTitle) {
    const targetId = $menuTitle.data('target');
    const $targetSubmenu = $('#' + targetId);
    const isCurrentlyOpen = $menuTitle.hasClass('active');
    
    // 모든 서브메뉴 닫기
    $('.menu-title').removeClass('active');
    $('.submenu').removeClass('open');
    
    // 현재 메뉴가 닫혀있었다면 열기
    if (!isCurrentlyOpen) {
        $menuTitle.addClass('active');
        $targetSubmenu.addClass('open');
    }
}

// 장바구니 배지 업데이트
function updateCartBadge() {
    if (cartCount > 0) {
        $cartBadge.text(cartCount > 99 ? '99+' : cartCount);
        $cartBadge.addClass('show');
    } else {
        $cartBadge.removeClass('show');
    }
}

// 테스트 함수들
function toggleCartBadge() {
    $cartBadge.toggleClass('show');
}

function addToCart() {
    cartCount++;
    updateCartBadge();
    $cartBadge.addClass('bounce');
    setTimeout(function() {
        $cartBadge.removeClass('bounce');
    }, 500);
}

function clearCart() {
    cartCount = 0;
    updateCartBadge();
}

// 이벤트 리스너 등록
$hamburgerBtn.on('click', toggleSideMenu);
$sideMenuOverlay.on('click', closeSideMenu);

// 서브메뉴 토글 이벤트 등록
$('.menu-title').on('click', function(e) {
    e.preventDefault();
    toggleSubmenu($(this));
});

// 장바구니 버튼 클릭 이벤트
$cartBtn.on('click', function() {
    alert('장바구니 페이지로 이동합니다!');
});

// ESC 키로 사이드 메뉴 닫기
$(document).on('keydown', function(e) {
    if (e.key === 'Escape' && $sideMenu.hasClass('open')) {
        closeSideMenu();
    }
});

// 터치 스와이프로 사이드 메뉴 닫기
let touchStartX = 0;

$sideMenu.on('touchstart', function(e) {
    touchStartX = e.originalEvent.touches[0].clientX;
});

$sideMenu.on('touchmove', function(e) {
    const touchCurrentX = e.originalEvent.touches[0].clientX;
    const diff = touchStartX - touchCurrentX;
    
    if (diff > 50) { // 왼쪽으로 50px 이상 스와이프하면 메뉴 닫기
        closeSideMenu();
    }
});

// 초기 배지 상태 설정
updateCartBadge();

// 페이지 로드 시 메뉴가 열려있으면 닫기
$(window).on('load', function() {
    if ($(window).width() >= 768) {
        closeSideMenu();
    }
});

// 화면 크기 변경 시 메뉴 닫기
$(window).on('resize', function() {
    if ($(window).width() >= 768) {
        closeSideMenu();
    }
});

// 전역 함수로 노출 (필요한 경우)
window.toggleCartBadge = toggleCartBadge;
window.addToCart = addToCart;
window.clearCart = clearCart;

//fullmenu 부분
let menuHoverTimer;
    const $navMenu = $('#navMenu');
    const $fullmenu = $('#fullmenu');

    function showFullMenu() {
        clearTimeout(menuHoverTimer);
        $fullmenu.addClass('active');
    }

    function hideFullMenu() {
        menuHoverTimer = setTimeout(() => {
            $fullmenu.removeClass('active');
        }, 200);
    }

    // 네비게이션 메뉴에 마우스 호버 이벤트
    $navMenu.on('mouseenter', showFullMenu);
    $navMenu.on('mouseleave', hideFullMenu);

    // 풀메뉴에 마우스 호버 이벤트
    $fullmenu.on('mouseenter', function() {
        clearTimeout(menuHoverTimer);
    });
    $fullmenu.on('mouseleave', hideFullMenu);

    //여기까지

let currentSlide = 0;
const totalSlides = $('.banner-slide').length;
let slideInterval;
let isHovered = false; // 호버 상태 추가

// 슬라이드 변경 함수
function changeSlide(index) {
    $('.banner-slide').removeClass('active prev');
    $('.nav-dot').removeClass('active');
    
    $('.banner-slide').eq(currentSlide).addClass('prev');
    $('.banner-slide').eq(index).addClass('active');
    $('.nav-dot').eq(index).addClass('active');
    
    // 배경색 변경
    const slideClass = $('.banner-slide').eq(index).attr('class').split(' ').find(cls => cls.startsWith('slide-'));
    $('.banner-container').removeClass('slide-1 slide-2 slide-3 slide-4').addClass(slideClass);
    
    currentSlide = index;
}

// 자동 슬라이드 - 시간을 더 길게 설정
function startAutoSlide() {
    stopAutoSlide(); // 기존 인터벌 제거
    if (!isHovered) { // 호버 상태가 아닐 때만 시작
        slideInterval = setInterval(function() {
            if (!isHovered) { // 호버 상태 재확인
                const nextSlide = (currentSlide + 1) % totalSlides;
                changeSlide(nextSlide);
            }
        }, 4000); // 4초로 변경 (더 느리게)
    }
}

function stopAutoSlide() {
    if (slideInterval) {
        clearInterval(slideInterval);
        slideInterval = null;
    }
}

// 이벤트 리스너
$('.nav-dot').click(function() {
    const slideIndex = $(this).data('slide');
    changeSlide(slideIndex);
    stopAutoSlide();
    // 클릭 후 3초 뒤에 자동 슬라이드 재시작
    setTimeout(() => {
        if (!isHovered) {
            startAutoSlide();
        }
    }, 3000);
});

$('.next-arrow').click(function() {
    const nextSlide = (currentSlide + 1) % totalSlides;
    changeSlide(nextSlide);
    stopAutoSlide();
    setTimeout(() => {
        if (!isHovered) {
            startAutoSlide();
        }
    }, 3000);
});

$('.prev-arrow').click(function() {
    const prevSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    changeSlide(prevSlide);
    stopAutoSlide();
    setTimeout(() => {
        if (!isHovered) {
            startAutoSlide();
        }
    }, 3000);
});

// 버튼 호버 효과
$('.btn').hover(
    function() {
        $(this).addClass('animate__pulse');
    },
    function() {
        $(this).removeClass('animate__pulse');
    }
);

// 마우스 오버시 자동 슬라이드 정지 - 개선된 버전
$('.banner-container').hover(
    function() {
        isHovered = true;
        stopAutoSlide();
    },
    function() {
        isHovered = false;
        // 마우스가 벗어난 후 1초 뒤에 자동 슬라이드 재시작
        setTimeout(() => {
            if (!isHovered) {
                startAutoSlide();
            }
        }, 1000);
    }
);

// 키보드 네비게이션
$(document).keydown(function(e) {
    if (e.keyCode === 37) { // 왼쪽 화살표
        $('.prev-arrow').click();
    } else if (e.keyCode === 39) { // 오른쪽 화살표
        $('.next-arrow').click();
    }
});



// 반응형 텍스트 크기 조정
function adjustTextSize() {
    const windowWidth = $(window).width();
    if (windowWidth < 768) {
        $('.text-content h1').css('font-size', '2rem');
    } else {
        $('.text-content h1').css('font-size', '3.5rem');
    }
}

$(window).resize(adjustTextSize);
adjustTextSize();

// 페이지 로드 후 자동 슬라이드 시작 - 약간의 딜레이 추가
$(document).ready(function() {
    setTimeout(startAutoSlide, 1000); // 1초 후 시작
});


    //MOST 부분

    $(document).ready(function() {
    let currentIndex = 0;
    const $slider = $('.most-slider');
    const $cards = $('.most-card');
    const totalCards = $cards.length;

    // 화면 크기에 따른 설정값 반환
    function getSliderConfig() {
        const windowWidth = $(window).width();
        
        if (windowWidth >= 1920) {
            // PC 큰 화면
            return {
                visibleCards: 4,
                cardWidth: 405
            };
        }else if (windowWidth >= 800) {
            // 태블릿
            return {
                visibleCards: 4,
                cardWidth: 405
            };
        } else {
            // 모바일
            return {
                visibleCards: 2,
                cardWidth: 212
            };
        }
    }

    function updateSlider() {
        const config = getSliderConfig();
        const translateX = -currentIndex * config.cardWidth;
        $slider.css('transform', `translateX(${translateX}px)`);
    }

    function resetSlider() {
        currentIndex = 0;
        updateSlider();
    }

    $('.nav-prev01').on('click', function() {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    });

    $('.nav-next01').on('click', function() {
        const config = getSliderConfig();
        if (currentIndex < totalCards - config.visibleCards) {
            currentIndex++;
            updateSlider();
        }
    });

    // 케이크 카드 클릭 이벤트
    $cards.on('click', function() {
        const index = $cards.index(this);
        console.log(`${index + 1}번째 케이크 클릭됨`);
        // 여기에 케이크 상세 페이지로 이동하는 로직을 추가할 수 있습니다
    });

    // 화면 크기 변경시 슬라이더 재설정
    $(window).on('resize', function() {
        resetSlider();
    });

    // 초기 설정
    updateSlider();
});


    //new 부분

    $(document).ready(function() {
    let currentIndex = 0;
    const $slider = $('.new-slider');
    const $cards = $('.new-card');
    const totalCards = $cards.length;

    // 화면 크기에 따른 설정값 반환
    function getSliderConfig() {
        const windowWidth = $(window).width();
        
        if (windowWidth >= 1920) {
            // PC 큰 화면
            return {
                visibleCards: 4,
                cardWidth: 405
            };
        }else if (windowWidth >= 800) {
            // 태블릿
            return {
                visibleCards: 3,
                cardWidth: 212
            };
        } else {
            // 모바일
            return {
                visibleCards: 2,
                cardWidth: 212
            };
        }
    }

    function updateSlider() {
        const config = getSliderConfig();
        const translateX = -currentIndex * config.cardWidth;
        $slider.css('transform', `translateX(${translateX}px)`);
    }

    function resetSlider() {
        currentIndex = 0;
        updateSlider();
    }

    $('.nav-prev02').on('click', function() {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    });

    $('.nav-next02').on('click', function() {
        const config = getSliderConfig();
        if (currentIndex < totalCards - config.visibleCards) {
            currentIndex++;
            updateSlider();
        }
    });

    // 케이크 카드 클릭 이벤트
    $cards.on('click', function() {
        const index = $cards.index(this);
        console.log(`${index + 1}번째 케이크 클릭됨`);
        // 여기에 케이크 상세 페이지로 이동하는 로직을 추가할 수 있습니다
    });

    // 화면 크기 변경시 슬라이더 재설정
    $(window).on('resize', function() {
        resetSlider();
    });

    // 초기 설정
    updateSlider();
});


});

// care 부분 시작

            // 메뉴 클릭 이벤트
            $('.submenu2 a').click(function(e) {
                e.preventDefault();
                
                // 모든 메뉴에서 active 클래스 제거
                $('.submenu2 a').removeClass('active');
                // 클릭한 메뉴에 active 클래스 추가
                $(this).addClass('active');
                
                // 모든 제품 컨테이너 숨기기
                $('.product-container').removeClass('active');
                
                // 선택한 카테고리의 제품 컨테이너 보이기
                var category = $(this).data('category');
                $('#' + category).addClass('active');
                
                // 모바일에서만 스크롤 효과 (PC에서는 레이아웃이 달라서 제외)
                if ($(window).width() < 1200) {
                    $('html, body').animate({
                        scrollTop: $('.care_right').offset().top - 20
                    }, 500);
                }
            });

            // 제품 카드 호버 효과
            $('.hair_card').hover(
                function() {
                    $(this).find('img').css('transform', 'scale(1.05)');
                },
                function() {
                    $(this).find('img').css('transform', 'scale(1)');
                }
            );

            // 터치 디바이스에서 카드 탭 효과
            $('.hair_card').on('touchstart', function() {
                $(this).addClass('touch-active');
            }).on('touchend', function() {
                var self = this;
                setTimeout(function() {
                    $(self).removeClass('touch-active');
                }, 200);
            });

            // 반응형 레이아웃 변경 감지
            $(window).resize(function() {
                // 윈도우 크기 변경 시 필요한 조정사항들
                $('.product-container.active').trigger('resize');
            });

    $(document).ready(function() {
        // 로딩 완료 후 애니메이션 시작
        $(window).on('load', function() {
            $('.loading').addClass('hidden');
            
            // 메인 제목 애니메이션
            setTimeout(function() {
                $('.fullbanner_text').css({
                    'opacity': '0',
                    'transform': 'translateY(-20px)'
                }).animate({
                    'opacity': '1'
                }, 800).css('transform', 'translateY(0)');
            }, 300);
            
            // 배너들 순차적 등장
            $('.banner').each(function(index) {
                var $banner = $(this);
                setTimeout(function() {
                    $banner.addClass('visible');
                }, 600 + (index * 200));
            });
        });

        // 스크롤 애니메이션
        function checkScroll() {
            $('.fade-in-text').each(function() {
                var elementTop = $(this).offset().top;
                var elementBottom = elementTop + $(this).outerHeight();
                var viewportTop = $(window).scrollTop();
                var viewportBottom = viewportTop + $(window).height();
                
                if (elementBottom > viewportTop && elementTop < viewportBottom) {
                    $(this).addClass('visible');
                }
            });
        }

        // 스크롤 이벤트 최적화 (throttle)
        var scrollTimer = null;
        $(window).on('scroll', function() {
            if (scrollTimer) {
                clearTimeout(scrollTimer);
            }
            scrollTimer = setTimeout(checkScroll, 50);
        });

        // 초기 체크
        checkScroll();

        // 터치 디바이스 지원
        if ('ontouchstart' in window) {
            $('.banner').on('touchstart', function() {
                $(this).addClass('touch-active');
            }).on('touchend', function() {
                var $this = $(this);
                setTimeout(function() {
                    $this.removeClass('touch-active');
                }, 150);
            });
        }

        // 성능 최적화: 이미지 lazy loading 시뮬레이션
        $('.banner img').each(function() {
            var $img = $(this);
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        observer.unobserve(entry.target);
                    }
                });
            });
            
            $img.css('opacity', '0.3');
            observer.observe(this);
        });
    });


});

$(document).ready(function() {
    // 스크롤 애니메이션 함수
    function checkScrollAnimation() {
        // 큰 리뷰 카드들 (review_bottom1)
        $('.review_bottom1').each(function(index) {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();
            
            // 요소의 일부가 뷰포트에 보이면 애니메이션 실행
            if (elementBottom > viewportTop + 100 && elementTop < viewportBottom - 100) {
                if (!$(this).hasClass('visible')) {
                    setTimeout(() => {
                        $(this).addClass('visible');
                    }, index * 200);
                }
            }
        });

        // 작은 리뷰 카드들 (review_card)
        $('.review_card').each(function(index) {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();
            
            if (elementBottom > viewportTop + 100 && elementTop < viewportBottom - 100) {
                if (!$(this).hasClass('visible')) {
                    setTimeout(() => {
                        $(this).addClass('visible bounce-in');
                    }, index * 150);
                }
            }
        });
    }

    // 스크롤 이벤트 (throttled)
    let scrollTimer = null;
    $(window).on('scroll', function() {
        if (scrollTimer) {
            clearTimeout(scrollTimer);
        }
        scrollTimer = setTimeout(checkScrollAnimation, 50);
    });

    // 초기 체크
    checkScrollAnimation();

    // 리뷰 카드 클릭 시 상세 보기 효과
    $('.review_card').click(function() {
        $(this).addClass('clicked');
        setTimeout(() => {
            $(this).removeClass('clicked');
        }, 300);
    });

    // 모바일 터치 지원
    if ('ontouchstart' in window) {
        $('.review_bottom1, .review_card').on('touchstart', function() {
            $(this).addClass('touch-active');
        }).on('touchend', function() {
            const $this = $(this);
            setTimeout(() => {
                $this.removeClass('touch-active');
            }, 150);
        });
    }



    // 이미지 lazy loading 시뮬레이션
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    $(img).removeClass('loading-shimmer').css('opacity', '1');
                    imageObserver.unobserve(img);
                }
            });
        });

        $('img').each(function() {
            $(this).addClass('loading-shimmer').css('opacity', '0.7');
            imageObserver.observe(this);
        });
    }

    // 반응형 레이아웃 변경 감지 (3단계만)
    function handleResponsiveLayout() {
        const windowWidth = $(window).width();
        
        if (windowWidth >= 1920) {
            console.log('PC 모드 (1920px+)');
        } else if (windowWidth >= 800) {
            console.log('태블릿 모드 (800px+)');
        } else {
            console.log('모바일 모드 (~800px)');
        }
    }

    // 윈도우 리사이즈 이벤트
    $(window).on('resize', function() {
        handleResponsiveLayout();
        checkScrollAnimation();
    });

    // 초기 레이아웃 설정
    handleResponsiveLayout();

    // 스무스한 페이지 로딩 애니메이션
    $(window).on('load', function() {
        $('body').addClass('loaded');
        
        // 순차적 애니메이션
        setTimeout(() => {
            $('.review_top').css('animation-play-state', 'running');
        }, 100);
        
        setTimeout(() => {
            $('.review_box h1').css('animation-play-state', 'running');
        }, 400);
        
        // 초기 뷰포트에 있는 요소들 체크
        checkScrollAnimation();
    });

    // 성능 최적화를 위한 디바운스 함수
    function debounce(func, wait, immediate) {
        let timeout;
        return function executedFunction() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // 디바운스된 스크롤 이벤트
    const debouncedScroll = debounce(checkScrollAnimation, 100);
    $(window).off('scroll').on('scroll', debouncedScroll);


});