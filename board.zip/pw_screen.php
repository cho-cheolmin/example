<? 
	session_start(); 
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/base.css">
		<link rel="stylesheet" href="css/id_screen.css">
	   <link rel="stylesheet" href="css/common.css">
		<style>

		</style>
		
		 
<script>

 </script>
		</head>
	<body>
<div class="box">
   
   <img src="img/logotype_b_new.png" alt="로고" class="logo">
</div>
<div class="fulllogin">
    <div class="login_text">
     <p class="text1">FIND PASSWORD</p>
     <p class="text2">비밀번호가 기억나지 않으신가요?</p>
    </div>

<div id="login">
    <form  name="member_form" method="post" action="id_search.php"> 
<p> <label for="pid">ID</label><input type="text" id="pid" name="id"></p>

<p> <label for="a2" class="b2">HP</label><input type="text" id="hp" name="hp"></p>
<p class="center"> 
     <button class="button">완료</button>

 </p>
</form>
</div>

</div>
    


            <footer>
                <div class="footer-container">
                    <div class="footer-logo">
                        <img src="img/logow.png" alt="AROMATICA" class="footer-logo-img">
                    </div>
             
                    <div class="footer-buttons">
                        <a href="#" class="footer-btn">주문 및 문의</a>
                        <a href="#" class="footer-btn">B2B</a>
                        <a href="#" class="footer-btn">관련 사이트</a>
                    </div>
             
                    <div class="footer-content">
                        <div class="footer-left">
                            <div class="footer-title">개인정보처리방침</div>
                            <div class="footer-title" style="margin-bottom: 25px;">윤리규범 실천지침</div>
                            
                            <div class="footer-info">
                                서울 강남구 강남대로162길 41-4 <br>
                                Tel. 070-4132-4179｜Fax. 02-540-5297｜E-mail. ir@aromatica.co.kr
                            </div>
                        </div>
             
                        <div class="footer-right">
                            <div class="footer-contact">
                                <div class="contact-label">Customer Center</div>
                                <div class="contact-number">1600-3689</div>
                            </div>
             
                            <div class="footer-contact">
                                <div class="contact-label">채용 문의</div>
                                <div class="contact-number">recruit@aromatica.co.kr</div>
                                <div class="contact-hours">
                                    Mon-Fri 10:00 - 17:00
                                </div>
                            </div>
                        </div>
                    </div>
             
                    <div class="footer-social">
                        <a href="#" class="social-icon">
                            <img src="img/lets-icons_insta-fill.png" alt="Instagram">
                        </a>
                        <a href="#" class="social-icon">
                            <img src="img/mingcute_youtube-fill.png" alt="YouTube">
                        </a>
                        <a href="#" class="social-icon">
                            <img src="img/iconoir_tiktok-solid.png" alt="TikTok">
                        </a>
                    </div>
             
                    <div class="footer-bottom">
                        <div class="copyright">
                            (주) 아로마티카<br>
             Since 2004 © 2023 AROMATICA All rights reserved. In God we trust.
                        </div>
                    </div>
                </div>
             </footer>
  
  
</body>
</html>