<? 
	session_start(); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head> 
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/greet.css" rel="stylesheet" type="text/css" media="all">
</head>

<body><html>
<head> 
<meta charset="utf-8">
<link href="css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="css/greet.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/exam.css">
	<link rel="stylesheet" href="css/rwd_jcm.css">

	<script src="js/jquery-1.11.2.min.js"></script>
	<script src="js/main.js"></script>	
<script>
$(function(){
 $(".nav2> li >a").on("mouseenter",function(){
   $(".nav2 li a").css("background","none");
   $(".sub").stop().slideUp(500);
   $(".nav2 li a").css("text-decoration","none");
   $(".nav2 li a").css("color","gray");
	$(this).css("background","#2c2a29");
	$(this).css("text-decoration","underline").css("color","#64a70b");	
	$(this).next().stop().slideDown(500);
 });
 
     $(".menu").on("mouseleave",function(){
     $(".nav2 li a").css("background","none");
	 $(".sub").stop().slideUp(500);
	 $(".nav2 li a").css("color","gray");
	 $(".nav2 li a").css("text-decoration","none");
	});

});
</script>
</head>
<body>

<div id="header">
	<? include "header.php"; ?>

</div>

<div id="wrap">
	<div id="content">
		<div id="col2">
			<div id="title">
				<img src="img/title_greet.png">
			</div>
			<div class="clear"></div>

			<div id="write_form_title">
				<img src="img/write_form_title.jpg">
			</div>
			<div class="clear"></div>
			<form name="board_form" method="post" action="insert1.php">
				<div id="write_form">
					<div class="write_line"></div>
					<div id="write_row1">
						<div class="col1"> 아이디 </div>
						<div class="col2"><?=$_SESSION['userid']?> </div>
						<div class="col3"><input type="checkbox" name="html_ok" value="y"> HTML 쓰기 </div>
					</div>
					<div class="write_line"></div>
					<div id="write_row2">
						<div class="col1"> 제목 </div>
						<div class="col2"><input type="text" name="subject"></div>
					</div>
					<div class="write_line"></div>
					<div id="write_row3">
						<div class="col1"> 내용 </div>
						<div class="col2"><textarea rows="15" cols="79" name="content"></textarea></div>
					</div>
					<div class="write_line"></div>
				</div>
				
				<div id="write_button"><input type="image" src="img/dhksfy.jpg">&nbsp;
				        <a href="list.php?page=<?=$page?>"><img src="img/ahrfhr.jpg" alt=""></a>
				</div>
			</form>
		</div>
	</div>
</div>

</body>
</html>