create table member_bd(
id char(15)  not null,
pass char(15) not null,
name char(10) not null,
tel char(20) not null,
email char(80),
primary key(id)
)engine=innoDB charset=utf8;