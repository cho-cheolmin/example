<?
           session_start();
?>
<meta charset="utf-8">
<?
 
   include "dbconn.php";
   mysqli_query($connect,'set names utf8');  

 $id=$_POST['id'];
 $hp=$_POST['tel'];
  
 $sql ="select * from member_bd where id='$id'  AND tel='$hp'";

 $result = mysqli_query( $connect,$sql);
$num_match = mysqli_fetch_array($result);

if(!empty($num_match)){
  echo "<script>alert('회원님의 비밀번호는 $num_match[pass]입니다. 로그인해주세요*^^*'); location.href='login_form.php';</script>";
  //알람창을 띄워주고, 로그인화면으로 넘깁니다. 알람창을 사용하기 위해서는  <script>안에 있어야함
 }

 else{
  echo $hp."<script>alert('비밀번호 찾기 실패');</script>";
 }
   mysqli_close($connect);     

