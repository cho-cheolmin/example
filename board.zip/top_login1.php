<? 
	session_start(); 
?>
	<div id="top_login">
  
	  
	  <?
    if(!$_SESSION['userid'] )
	{
?>
          <a href="login_form.php">Login</a> 
<?
	}
	else
	{
?>
		<?=$_SESSION['userid']?> |
		<a href="logout.php">Logout</a> 
<?
	}
?>
	  
     </div>
  
