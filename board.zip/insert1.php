<? session_start(); ?>
<meta charset="utf-8">

<?php
$userid = $_SESSION['userid'];
$username = $_SESSION ['username'];
$subject = $_POST['subject'];
$content = $_POST['content'];

if(!$_SESSION['userid']){
    echo("
    <script>
    window.alert('로그인 후 이용해 주세요.')
    history.go(-1)
    </script>
    ");
    exit;
}

if(!$_POST['subject']){
    echo("
    <script>
    window.alert('제목을 입력하세요.')
    history.go(-1)
    </script>
    ");
    exit;
}

if(!$_POST['content']){
    echo("
    <script>
    window.alert('내용을 입력하세요.')
    history.go(-1)
    </script>
    ");
    exit;
}

$regist_day = date("Y-m-d (H:i)");
include "dbconn.php";
$mode = $_GET ['modify'];
$num = $_GET ['num'];

if (isset($_GET["mode"]))
$mode = $_GET["mode"];
else
$mode = "";
if ($mode=="modify")
{
    $sql = "update boardlist set subject='$subject', content='$content' where num=$num";
}
else
{
    if($html_ok=="y")
    {
        $is_html = "y";
    }
    else
    {
        $is_html = "";
        $content = htmlspecialchars($content);
    }
    $sql = "insert into boardlist (id, name, subject, content, regist_day, hit, is_html)";
    $sql .= "values('$userid','$username','$subject','$content','$regist_day', 0, '$is_html')";
}
mysqli_query($connect,$sql);
mysqli_close($connect);

echo"
<script>
location.href = 'list.php?page=$page';
</script>
";
?>
