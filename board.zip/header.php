<nav class="navbar" id="navbar">
        <div class="logo">AROMATICA</div>
        <ul class="nav-menu" id="navMenu">
            <li><a href="#" data-menu="PRODUCT">PRODUCT</a></li>
            <li><a href="#" data-menu="BRAND">BRAND</a></li>
            <li><a href="#" data-menu="MAGAZINE">MAGAZINE & CURATION</a></li>
            <li><a href="#" data-menu="event">SUPPORT</a></li>
        </ul>
        <div style="display: flex; gap: 20px;">
		<? include "top_login1.php"; ?>
            <a href="#" style="text-decoration: none; color: inherit;">Cart</a>
        </div>
    </nav>

    <div class="fullmenu-container" id="fullmenu">
        <div class="fullmenu-grid">
            <div class="menu-section">
                <h3>PRODUCT</h3>
                <ul class="menu-list">
                    <li><a href="#">바디케어</a></li>
                    <li><a href="#">헤어케어</a></li>
                    <li><a href="#">스킨케어</a></li>
                </ul>
            </div>
            
            <div class="menu-section">
                <h3>BRAND</h3>
                <ul class="menu-list">
                    <li><a href="#">브랜드 스토리</a></li>
                    <li><a href="#">창립 철학</a></li>
                    <li><a href="#">캠페인 히스토리</a></li>
                    <li><a href="#">지속가능경영 비전</a></li>
                </ul>
            </div>
            
            <div class="menu-section">
                <h3>MAGAZINE & CURATION</h3>
                <ul class="menu-list">
                    <li><a href="#">나에게 맞는 제품 추천</a></li>
                    <li><a href="#">스킨케어 팁</a></li>
                    <li><a href="#">헤어케어 루틴</a></li>
                    <li><a href="#">친환경 생활 콘텐츠</a></li>
                    <li><a href="#">인터뷰 및 고객 스토리</a></li>
                </ul>
            </div>
            
            <div class="menu-section">
                <h3>SUPPORT</h3>
                <ul class="menu-list">
                    <li><a href="#">자주 묻는 질문</a></li>
                    <li><a href="#">1:1 문의</a></li>
                    <li><a href="#">배송/반품/환불 안내</a></li>
                    <li><a href="#">공지사항</a></li>
                    <li><a href="#">제품 인증서 다운로드</a></li>
                </ul>
            </div>
        </div>
    </div>

</body>
</html>