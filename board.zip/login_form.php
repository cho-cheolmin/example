<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>웹표준/웹접근성</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/index.css">
<style>

</style>
</head>
<body>
<div class="login">
   <div class="box">
   
   <img src="img/logotype_b_new.png" alt="로고" class="logo">
    </div>


    <div id="login">
	      <form  name="member_form" method="post" action="login.php"> 
	  <p> <label for="name">ID</label><input type="text" id="name" name="id"></p>
      <p>    <label for="pwd">Password</label><input type="password" id="pwd" name="pass"></p>
  <p class="center"> <input type="submit"  value="로그인" class="login-button"> 
   <a href="member_conditions.html" class="login-button1">회원가입</a>
	   </p>
	  </form>
     </div>
     

     <div class="group">
       
        
        <a href="id_screen.php" class="mm">아이디 찾기</a>
        <span>|</span>
        <a href="pw_screen.php" class="mm">비밀번호 찾기</a>
     </div>

</div>

<footer>
   <div class="footer-container">
       <div class="footer-logo">
           <img src="img/logow.png" alt="AROMATICA" class="footer-logo-img">
       </div>

       <div class="footer-buttons">
           <a href="#" class="footer-btn">주문 및 문의</a>
           <a href="#" class="footer-btn">B2B</a>
           <a href="#" class="footer-btn">관련 사이트</a>
       </div>

       <div class="footer-content">
           <div class="footer-left">
               <div class="footer-title">개인정보처리방침</div>
               <div class="footer-title" style="margin-bottom: 25px;">윤리규범 실천지침</div>
               
               <div class="footer-info">
                   서울 강남구 강남대로162길 41-4 <br>
                   Tel. 070-4132-4179｜Fax. 02-540-5297｜E-mail. ir@aromatica.co.kr
               </div>
           </div>

           <div class="footer-right">
               <div class="footer-contact">
                   <div class="contact-label">Customer Center</div>
                   <div class="contact-number">1600-3689</div>
               </div>

               <div class="footer-contact">
                   <div class="contact-label">채용 문의</div>
                   <div class="contact-number">recruit@aromatica.co.kr</div>
                   <div class="contact-hours">
                       Mon-Fri 10:00 - 17:00
                   </div>
               </div>
           </div>
       </div>

       <div class="footer-social">
           <a href="#" class="social-icon">
               <img src="img/lets-icons_insta-fill.png" alt="Instagram">
           </a>
           <a href="#" class="social-icon">
               <img src="img/mingcute_youtube-fill.png" alt="YouTube">
           </a>
           <a href="#" class="social-icon">
               <img src="img/iconoir_tiktok-solid.png" alt="TikTok">
           </a>
       </div>

       <div class="footer-bottom">
           <div class="copyright">
               (주) 아로마티카<br>
Since 2004 © 2023 AROMATICA All rights reserved. In God we trust.
           </div>
       </div>
   </div>
</footer>
</body>
</html>