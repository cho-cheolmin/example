<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>웹표준/웹접근성</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/index.css">
<style>

</style>
</head>
<body>
<div class="login">
   <div class="box">
   <img src="img/aro.png" alt="arrow" class="arrow">
   <img src="img/10b_logo.jpeg" alt="로고" class="logo">
    </div>


    <div id="login">
	      <form  name="member_form" method="post" action="login.php"> 
	  <p> <label for="name">ID</label><input type="text" id="name" name="id"></p>
      <p>    <label for="pwd">Password</label><input type="password" id="pwd" name="pass"></p>
  <p class="center"> <input type="submit"  value="로그인" class="login-button"> 
   <a href="member_conditions.html" class="login-button1">회원가입</a>
	   </p>
	  </form>
     </div>
     

     <div class="group">
       
        
        <a href="id_screen.php" class="mm">아이디 찾기</a>
        <span>|</span>
        <a href="pw_screen.php" class="mm">비밀번호 찾기</a>
     </div>

</div>

<footer class="footer">
   <div class="footerbox">
       <p>상호명 : (주)오가다</p>
       <p>주소 : 서울 강남구 논현로 829 2층</p>
       <p>사업자번호 : 101-86-51922</p>
       <p>전화(고객의 소리) : 02-738-0124 &nbsp; 팩스 : 02-738-0127</p>
       <p>E-mail : changup@10billioncoffee.com</p>
   </div>

   <div class="footer-icons">
      <a href="https://www.instagram.com/10billioncoffee/" target="_blank" class="icon">
         <img src="img/insta.png" alt="인스타그램"></a>
      <a href="https://www.youtube.com/@10billioncoffee" target="_blank" class="icon">
         <img src="img/youtube.png" alt="유튜브"></a>
      <a href="https://blog.naver.com/10billioncoffee" target="_blank" class="icon">
         <img src="img/naver.png" alt="네이버"></a>
      <a href="https://pf.kakao.com/_xfvwMn" target="_blank" class="icon">
         <img src="img/kakao.png" alt="카카오톡"></a>
   </div>
</footer>
</body>
</html>