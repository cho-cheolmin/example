$(function(){
    function listMore(){
        const $items = $("#hair_box li");
        const totalItems = $items.length;
        let showCount = 0;

        const winWidth = $(window).width();
        if(winWidth <= 540){
            showCount = 1;
        }else if (winWidth <= 640){
            showCount = 2;
        }else if (winWidth <= 768){
            showCount = 3;
        }else if (winWidth <= 1124){
            showCount = 4;
        }else {
            showCount = 5;
        }

        $items.hide();
        $items.slice(0, showCount).show();

        $(".more_btn").off("click").on("click",function(){
            let visibleCount = $("#hair_box li:visible").length;
            let nextCount = visibleCount + showCount;
            if (nextCount > totalItems) nextCount = totalItems;

            $items.slice(0, nextCount).show();
            if (nextCount === totalItems){
                $(".more_btn").hide();
            }
        });

        if (showCount < totalItems) {
            $(".more_btn").show();
        }else {
            $(".more_btn").hide();
        }
    }


    listMore();

    $(window).on("resize",function(){
        listMore();
    })

});